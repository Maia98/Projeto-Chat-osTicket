            <footer class="footer">
                <div class="row">
                    <div class="col-md-12" style="text-align: center;">
                        <p>Copyright &copy; <?php echo date('Y'); ?> <?php echo (string) $ost->company ?: 'osTicket.com'; ?> - Todos os direitos reservados.</p>
                    </div>
                </div>
            </footer>
        </div>
    </div>


<div id="overlay"></div>
<div id="loading">
    <h4><?php echo __('Please Wait!');?></h4>
    <p><?php echo __('Please wait... it will take a second!');?></p>
</div>
<?php
if (($lang = Internationalization::getCurrentLanguage()) && $lang != 'en_US') { ?>
    <script type="text/javascript" src="ajax.php/i18n/<?php echo $lang; ?>/js"></script>
<?php } ?>
</body>
</html>
