<?php
if(!defined('OSTADMININC') || !$thisstaff || !$thisstaff->isAdmin() || !$config) die('Access Denied');

$gmtime = Misc::gmtime();
?>
<h2><?php echo __('System Settings and Preferences');?> - <span class="ltr">osTicket (<?php echo $cfg->getVersion(); ?>)</span></h2>
<form action="settings.php?t=system" method="post" id="save">
<?php csrf_token(); ?>
<input type="hidden" name="t" value="system" >
<table class="form_table settings_table" style="width: 100%;">
    <thead>
        <tr>
            <th colspan="2" style="width: 100%;">
                <h4><?php echo __('System Settings and Preferences'); ?></h4>
                <em><b><?php echo __('General Settings'); ?></b></em>
            </th>
        </tr>
    </thead>
    <tbody>

        <tr>
            <td width="220" class="required"><?php echo __('Helpdesk Status');?>&nbsp;<font class="error"><?php echo $config['isoffline']?'osTicket '.__('Offline'):''; ?></font>:</td>
            <td>
                <div class="col-md-2">
                    <label>
                        <input type="radio" name="isonline"  value="1"   <?php echo $config['isonline']?'checked="checked"':''; ?> />&nbsp;<b><?php echo __('Online'); ?></b>&nbsp;
                    </label>
                    <label>
                        <input type="radio" name="isonline"  value="0"   <?php echo !$config['isonline']?'checked="checked"':''; ?> />&nbsp;<b><?php echo __('Offline'); ?></b>
                        <i class="help-tip icon-question-sign" href="#helpdesk_status"></i>
                    </label>
                </div>
            </td>
        </tr>
        <tr>
            <td class="required"><?php echo __('Helpdesk URL');?>:&nbsp;<font class="error">*&nbsp;<?php echo $errors['helpdesk_url']; ?></font></td>
            <td style="padding-top: 10px;">
                <div class="col-md-5">
                    <input type="text" class="form-control" size="40" name="helpdesk_url" value="<?php echo $config['helpdesk_url']; ?>">
                </div>
                <i class="help-tip icon-question-sign" href="#helpdesk_url"></i>
        </td>
        </tr>
        <tr>
            <td class="required"><?php echo __('Helpdesk Name/Title');?>:&nbsp;<font class="error">*&nbsp;<?php echo $errors['helpdesk_title']; ?></font></td>
            <td style="padding-top: 10px;">
                <div class="col-md-5">
                    <input type="text" class="form-control" size="40" name="helpdesk_title" value="<?php echo $config['helpdesk_title']; ?>">
                </div>
                <i class="help-tip icon-question-sign" href="#helpdesk_name_title"></i>
            </td>
        </tr>
        <tr>
            <td class="required"><?php echo __('Default Department');?>:&nbsp;<font class="error">*&nbsp;<?php echo $errors['default_dept_id']; ?></font></td>
            <td <td style="padding-top: 10px;">
                <div class="col-md-5">
                    <select name="default_dept_id" class="form-control">
                        <option value="">&mdash; <?php echo __('Select Default Department');?> &mdash;</option>
                        <?php
                        $sql='SELECT dept_id,dept_name FROM '.DEPT_TABLE.' WHERE ispublic=1';
                        if(($res=db_query($sql)) && db_num_rows($res)){
                            while (list($id, $name) = db_fetch_row($res)){
                                $selected = ($config['default_dept_id']==$id)?'selected="selected"':''; ?>
                                <option value="<?php echo $id; ?>"<?php echo $selected; ?>><?php echo $name; ?> <?php echo __('Dept');?></option>
                            <?php
                            }
                        } ?>
                    </select>
                </div>
                <i class="help-tip icon-question-sign" href="#default_department"></i>
            </td>
        </tr>

        <tr>
            <td><?php echo __('Default Page Size');?>:</td>
            <td style="padding-top: 10px;">
                <div class="col-md-5">
                    <select name="max_page_size" class="form-control">
                        <?php
                         $pagelimit=$config['max_page_size'];
                        for ($i = 5; $i <= 50; $i += 5) {
                            ?>
                            <option <?php echo $config['max_page_size']==$i?'selected="selected"':''; ?> value="<?php echo $i; ?>"><?php echo $i; ?></option>
                            <?php
                        } ?>
                    </select>
                </div>
                <i class="help-tip icon-question-sign" href="#default_page_size"></i>
            </td>
        </tr>
        <tr>
            <td><?php echo __('Default Log Level');?>:<font class="error">&nbsp;<?php echo $errors['log_level']; ?></font></td>
            <td style="padding-top: 10px;">
                <div class="col-md-5">
                    <select name="log_level" class="form-control">
                        <option value=0 <?php echo $config['log_level'] == 0 ? 'selected="selected"':''; ?>><?php echo __('None (Disable Logger)');?></option>
                        <option value=3 <?php echo $config['log_level'] == 3 ? 'selected="selected"':''; ?>> <?php echo __('DEBUG');?></option>
                        <option value=2 <?php echo $config['log_level'] == 2 ? 'selected="selected"':''; ?>> <?php echo __('WARN');?></option>
                        <option value=1 <?php echo $config['log_level'] == 1 ? 'selected="selected"':''; ?>> <?php echo __('ERROR');?></option>
                    </select>
                </div>
                <i class="help-tip icon-question-sign" href="#default_log_level"></i>
            </td>
        </tr>
        <tr>
            <td><?php echo __('Purge Logs');?>:</td>
            <td style="padding-top: 10px;">
                <div class="col-md-5">
                    <select name="log_graceperiod" class="form-control">
                        <option value=0 selected><?php echo __('Never Purge Logs');?></option>
                        <?php
                        for ($i = 1; $i <=12; $i++) {
                            ?>
                            <option <?php echo $config['log_graceperiod']==$i?'selected="selected"':''; ?> value="<?php echo $i; ?>">
                                <?php echo sprintf(_N('After %d month', 'After %d months', $i), $i);?>
                            </option>
                            <?php
                        } ?>
                    </select>
                </div>
                <i class="help-tip icon-question-sign" href="#purge_logs"></i>
            </td>
        </tr>
        <tr>
            <td width="180"><?php echo __('Default Name Formatting'); ?>:</td>
            <td style="padding-top: 10px;">
                <div class="col-md-5">
                    <select name="name_format" class="form-control">
                        <?php foreach (PersonsName::allFormats() as $n=>$f) {
                            list($desc, $func) = $f;
                            $selected = ($config['name_format'] == $n) ? 'selected="selected"' : ''; ?>
                                            <option value="<?php echo $n; ?>" <?php echo $selected;
                                                ?>><?php echo __($desc); ?></option>
                        <?php } ?>
                    </select>
                </div>
                <i class="help-tip icon-question-sign" href="#default_name_formatting"></i>
            </td>
        </tr>
        <tr>
            <th colspan="2">
                <em><b><?php echo __('Date and Time Options'); ?></b>&nbsp;
                <i class="help-tip icon-question-sign" href="#date_time_options"></i>
                </em>
            </th>
        </tr>
        <tr>
            <td class="required"><?php echo __('Time Format');?>:&nbsp;<font class="error">*&nbsp;<?php echo $errors['time_format']; ?></font></td>
            <td style="padding-top: 10px;">
                <div class="col-md-5">
                    <input type="text" class="form-control" name="time_format" value="<?php echo $config['time_format']; ?>">
                        <em><?php echo Format::date($config['time_format'], $gmtime, $config['tz_offset'], $config['enable_daylight_saving']); ?></em></td>
                </div>
        </tr>
        <tr>
            <td class="required"><?php echo __('Date Format');?>:&nbsp;<font class="error">*&nbsp;<?php echo $errors['date_format']; ?></font></td>
            <td style="padding-top: 10px;">
                <div class="col-md-5">
                    <input type="text" class="form-control" name="date_format" value="<?php echo $config['date_format']; ?>">
                        <em><?php echo Format::date($config['date_format'], $gmtime, $config['tz_offset'], $config['enable_daylight_saving']); ?></em>
                </div>
            </td>
        </tr>
        <tr>
            <td width="220" class="required"><?php echo __('Date and Time Format');?>:&nbsp;<font class="error">*&nbsp;<?php echo $errors['datetime_format']; ?></font></td>
            <td style="padding-top: 10px;">
                <div class="col-md-5">
                    <input type="text" class="form-control" name="datetime_format" value="<?php echo $config['datetime_format']; ?>">
                            <em><?php echo Format::date($config['datetime_format'], $gmtime, $config['tz_offset'], $config['enable_daylight_saving']); ?></em>
                </div>
            </td>
        </tr>
        <tr>
            <td class="required"><?php echo __('Day, Date and Time Format');?>:&nbsp;<font class="error">*&nbsp;<?php echo $errors['daydatetime_format']; ?></font></td>
            <td style="padding-top: 10px;">
                <div class="col-md-5">
                    <input type="text" class="form-control" name="daydatetime_format" value="<?php echo $config['daydatetime_format']; ?>">
                </div>
                <div class="col-md-12">
                    <em><?php echo Format::date($config['daydatetime_format'], $gmtime, $config['tz_offset'], $config['enable_daylight_saving']); ?></em>
                </div>
            </td>
        </tr>
        <tr>
            <td class="required"><?php echo __('Default Time Zone');?>:&nbsp;<font class="error">*&nbsp;<?php echo $errors['default_timezone_id']; ?></font></td>
            <td style="padding-top: 10px;">
                <div class="col-md-5">
                    <select name="default_timezone_id" class="form-control">
                        <option value="">&mdash; <?php echo __('Select Default Time Zone');?> &mdash;</option>
                        <?php
                        $sql='SELECT id, offset,timezone FROM '.TIMEZONE_TABLE.' ORDER BY id';
                        if(($res=db_query($sql)) && db_num_rows($res)){
                            while(list($id, $offset, $tz)=db_fetch_row($res)){
                                $sel=($config['default_timezone_id']==$id)?'selected="selected"':'';
                                echo sprintf('<option value="%d" %s>GMT %s - %s</option>', $id, $sel, $offset, $tz);
                            }
                        }
                        ?>
                    </select>
                </div>
            </td>
        </tr>
        <tr>
            <td><?php echo __('Daylight Saving');?>:</td>
            <td>
                <div class="col-md-5">
                    <input type="checkbox" name="enable_daylight_saving" <?php echo $config['enable_daylight_saving'] ? 'checked="checked"': ''; ?>><?php echo __('Observe daylight savings');?>
                </div>
            </td>
        </tr>
    </tbody>
</table>
<p style="text-align: center; padding-top: 20px;">
    <input type="submit" class="btn btn-primary" name="submit" value="<?php echo __('Save Changes');?>">
    <input type="reset" class="btn btn-primary" name="reset" value="<?php echo __('Reset Changes');?>">
</p>
</form>
