<?php
if(!defined('OSTSTAFFINC') || !$staff || !$thisstaff) die('Access Denied');

$info=$staff->getInfo();
$info['signature'] = Format::viewableImages($info['signature']);
$info=Format::htmlchars(($errors && $_POST)?$_POST:$info);
$info['id']=$staff->getId();
?>
<form action="profile.php" method="post" id="save" autocomplete="off">
 <?php csrf_token(); ?>
 <input type="hidden" name="do" value="update">
 <input type="hidden" name="id" value="<?php echo $info['id']; ?>">
 <h2><?php echo __('My Account Profile');?></h2>
 <div class="col-md-12">
     <div class="row">
         <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="panel-title"><?php echo __('Account Information');?> (<em><?php echo __('Contact information');?></em>)</h3>
          </div>
          <div class="panel-body">
            <table>
        <tbody>
            <tr>
                <td width="180" class="required">
                    <?php echo __('Username');?>:
                </td>
                <td>
                    <div class="col-md-5">
                        <b><?php echo $staff->getUserName(); ?></b>&nbsp;<i class="help-tip icon-question-sign" href="#username"></i>
                </td>
            </tr>
            <tr>
                <td width="180" class="required">
                    <span class="error">*&nbsp;<?php echo $errors['firstname']; ?></span><?php echo __('First Name');?>:
                </td>
                <td>
                    <div class="col-md-5">
                        <input type="text" size="34" name="firstname" class="form-control" value="<?php echo $info['firstname']; ?>">
                        &nbsp;
                    </div>
                </td>
            </tr>
            <tr>
                <td width="180" class="required">
                    <span class="error">*&nbsp;<?php echo $errors['lastname']; ?></span><?php echo __('Last Name');?>:
                </td>
                <td>
                    <div class="col-md-5">
                        <input type="text" size="34" class="form-control" name="lastname" value="<?php echo $info['lastname']; ?>">
                        &nbsp;
                    </div>
                </td>
            </tr>
            <tr>
                <td width="180" class="required">
                    <span class="error">*&nbsp;<?php echo $errors['email']; ?></span><?php echo __('Email Address');?>:
                </td>
                <td>
                    <div class="col-md-5">
                        <input type="text" size="34" class="form-control" name="email" value="<?php echo $info['email']; ?>">
                        &nbsp;
                    </div>
                </td>
            </tr>
            <tr>
                <td width="180">
                    <span class="error">&nbsp;<?php echo $errors['phone']; ?></span><?php echo __('Phone Number');?>:
                </td>
                <td>
                    <div class="col-md-4">
                        <input type="text" class="form-control" name="phone" value="<?php echo $info['phone']; ?>">
                        &nbsp;
                    </div>
                </td>
            </tr>
            <tr>
                <td width="180">
                    <span>Telefone Externo:</span>
                </td>
                <td>
                    <div class="col-md-4">
                        <input type="text" class="form-control" name="phone_ext" value="<?php echo $info['phone_ext']; ?>">
                        &nbsp;<span class="error">&nbsp;<?php echo $errors['phone_ext']; ?></span>
                    </div>
                </td>
            </tr>
            <tr>
                <td width="180">
                    <?php echo __('Mobile Number');?>:
                </td>
                <td>
                    <div class="col-md-5">
                        <input type="text" class="form-control" name="mobile" value="<?php echo $info['mobile']; ?>">
                        &nbsp;<span class="error">&nbsp;<?php echo $errors['mobile']; ?></span>
                    </div>
                </td>
            </tr>
            <tr>
                <th colspan="2">
                    <em><strong><?php echo __('Preferences');?></strong>: <?php echo __('Profile preferences and settings.');?></em>
                </th>
            </tr>
            <tr>
                <td width="180" class="required">
                    <span class="error">*&nbsp;<?php echo $errors['timezone_id']; ?></span><?php echo __('Time Zone');?>:
                </td>
                <td>
                    <div class="col-md-9">
                        <select name="timezone_id" id="timezone_id" class="form-control">
                        <option value="0">&mdash; <?php echo __('Select Time Zone');?> &mdash;</option>
                        <?php
                        $sql='SELECT id, offset,timezone FROM '.TIMEZONE_TABLE.' ORDER BY id';
                        if(($res=db_query($sql)) && db_num_rows($res)){
                            while(list($id,$offset, $tz)=db_fetch_row($res)){
                                $sel=($info['timezone_id']==$id)?'selected="selected"':'';
                                echo sprintf('<option value="%d" %s>GMT %s - %s</option>',$id,$sel,$offset,$tz);
                            }
                        }
                        ?>
                    </select>
                    &nbsp;
                    </div>
                </td>
            </tr>
            <tr>
                <td>
                    <?php echo __('Preferred Language'); ?>:
                </td>
                <td>
                <div class="col-md-9">
            <?php
            $langs = Internationalization::availableLanguages(); ?>
                    <select name="lang" class="form-control">
                        <option value="">&mdash; <?php echo __('Use Browser Preference'); ?> &mdash;</option>
    <?php foreach($langs as $l) {
        $selected = ($info['lang'] == $l['code']) ? 'selected="selected"' : ''; ?>
                        <option value="<?php echo $l['code']; ?>" <?php echo $selected;
                            ?>><?php echo Internationalization::getLanguageDescription($l['code']); ?></option>
    <?php } ?>
                    </select>
                    <span class="error">&nbsp;<?php echo $errors['lang']; ?></span>
                    </div>
                </td>
            </tr>
            <tr>
                <td width="180"><?php echo __('Daylight Saving');?>:</td>
                <td>
                    <div class="col-md-8">
                        <input type="checkbox" name="daylight_saving" value="1" <?php echo $info['daylight_saving']?'checked="checked"':''; ?>>
                    <?php echo __('Observe daylight saving');?>
                    <em>(<?php echo __('Current Time');?>: <strong><?php echo Format::date($cfg->getDateTimeFormat(),Misc::gmtime(),$info['tz_offset'],$info['daylight_saving']); ?></strong>)</em>
                    </div>
                </td>
            </tr>
            <tr>
                <td width="180"><?php echo __('Maximum Page size');?>:</td>
                <td>
                    <div class="col-md-5">
                        <select name="max_page_size" class="form-control">
                            <option value="0">&mdash; <?php echo __('system default');?> &mdash;</option>
                            <?php
                            $pagelimit=$info['max_page_size']?$info['max_page_size']:$cfg->getPageSize();
                            for ($i = 5; $i <= 50; $i += 5) {
                                $sel=($pagelimit==$i)?'selected="selected"':'';
                                 echo sprintf('<option value="%d" %s>'.__('show %s records').'</option>',$i,$sel,$i);
                            } ?>
                        </select>
                        &nbsp;
                    </div>
                    <div class="col-md-3">
                        <?php echo __('per page.');?>
                    </div>
                </td>
            </tr>
            <tr>
                <td width="220"><?php echo __('Auto Refresh Rate');?>:</td>
                <td>
                    <div class="col-md-5">
                        <select name="auto_refresh_rate" class="form-control">
                          <option value="0">&mdash; <?php echo __('disable');?> &mdash;</option>
                          <?php
                          $y=1;
                           for($i=1; $i <=30; $i+=$y) {
                             $sel=($info['auto_refresh_rate']==$i)?'selected="selected"':'';
                             echo sprintf('<option value="%1$d" %2$s>'
                                .sprintf(
                                    _N('Every minute', 'Every %d minutes', $i), $i)
                                 .'</option>',$i,$sel);
                             if($i>9)
                                $y=2;
                           } ?>
                        </select>
                        &nbsp;
                    </div>
                    <div class="col-md-7">
                        <em><?php echo __('(Tickets page refresh rate in minutes.)');?></em>
                    </div>
                </td>
            </tr>
            <tr>
                <td width="180"><?php echo __('Default Signature');?>:</td>
                <td>
                    <div class="col-md-5">
                        <select name="default_signature_type" class="form-control">
                      <option value="none" selected="selected">&mdash; <?php echo __('None');?> &mdash;</option>
                      <?php
                       $options=array('mine'=>__('My Signature'),'dept'=>sprintf(__('Department Signature (%s)'),
                           __('if set' /* This is used in 'Department Signature (>if set<)' */)));
                      foreach($options as $k=>$v) {
                          echo sprintf('<option value="%s" %s>%s</option>',
                                    $k,($info['default_signature_type']==$k)?'selected="selected"':'',$v);
                      }
                      ?>
                    </select>
                    &nbsp;
                    </div>
                    <div class="col-md-7">
                        <em><?php echo __('(This can be selected when replying to a ticket)');?></em>
                        &nbsp;<span class="error">&nbsp;<?php echo $errors['default_signature_type']; ?></span>
                    </div>
                </td>
            </tr>
            <tr>
                <td width="180"><?php echo __('Default Paper Size');?>:</td>
                <td>
                    <div class="col-md-5">
                        <select name="default_paper_size" class="form-control">
                      <option value="none" selected="selected">&mdash; <?php echo __('None');?> &mdash;</option>
                      <?php

                      foreach(Export::$paper_sizes as $v) {
                          echo sprintf('<option value="%s" %s>%s</option>',
                                    $v,($info['default_paper_size']==$v)?'selected="selected"':'',__($v));
                      }
                      ?>
                    </select>
                    &nbsp;
                    </div>
                    <div class="col-md-7">
                        <em><?php echo __('Paper size used when printing tickets to PDF');?></em>
                        &nbsp;<span class="error">&nbsp;<?php echo $errors['default_paper_size']; ?></span>
                    </div>
                </td>
            </tr>
            <tr>
                <td><?php echo __('Show Assigned Tickets');?>:</td>
                <td>
                <div class="col-md-8">
                    <input type="checkbox" name="show_assigned_tickets" <?php echo $info['show_assigned_tickets']?'checked="checked"':''; ?>>
                    <em><?php echo __('Show assigned tickets on open queue.');?></em>
                    &nbsp;<i class="help-tip icon-question-sign" href="#show_assigned_tickets"></i></em>
                </div>
                </td>
            </tr>
            <tr>
                <th colspan="2">
                    <em><strong><?php echo __('Password');?></strong>: <?php echo __('To reset your password, provide your current password and a new password below.');?>&nbsp;<span class="error">&nbsp;<?php echo $errors['passwd']; ?></span></em>
                </th>
            </tr>
            <?php if (!isset($_SESSION['_staff']['reset-token'])) { ?>
            <tr>
                <td width="180">
                    <?php echo __('Current Password');?>:
                </td>
                <td>
                    <div class="col-md-5">
                        <input type="password" class="form-control" size="18" name="cpasswd" value="<?php echo $info['cpasswd']; ?>">
                    &nbsp;<span class="error">&nbsp;<?php echo $errors['cpasswd']; ?></span>
                    </div>    
                </td>
            </tr>
            <?php } ?>
            <tr>
                <td width="180">
                    <?php echo __('New Password');?>:
                </td>
                <td>
                    <div class="col-md-5">
                        <input type="password" class="form-control" size="18" name="passwd1" value="<?php echo $info['passwd1']; ?>">
                    &nbsp;<span class="error">&nbsp;<?php echo $errors['passwd1']; ?></span>
                    </div>
                </td>
            </tr>
            <tr>
                <td width="180">
                    <?php echo __('Confirm New Password');?>:
                </td>
                <td>
                    <div class="col-md-5">
                        <input type="password" class="form-control" size="18" name="passwd2" value="<?php echo $info['passwd2']; ?>">
                    &nbsp;<span class="error">&nbsp;<?php echo $errors['passwd2']; ?></span>
                    </div>
                </td>
            </tr>
            <tr>
                <th colspan="2">
                    <em><strong><?php echo __('Signature');?></strong>: <?php echo __('Optional signature used on outgoing emails.');?>
                    &nbsp;<span class="error">&nbsp;<?php echo $errors['signature']; ?></span>&nbsp;<i class="help-tip icon-question-sign" href="#signature"></i></em>
                </th>
            </tr>
            <tr>
                <td colspan=2>
                    <textarea class="richtext no-bar" name="signature" cols="21"
                        rows="5" style="width: 60%;"><?php echo $info['signature']; ?></textarea>
                    <em><?php echo __('Signature is made available as a choice, on ticket reply.');?></em>
                </td>
            </tr>
        </tbody>
    </table>
          </div>
        </div>
     </div>    
 </div>

<p style="text-align:center; margin-top: 30px">
    <input type="submit" class="btn btn-primary" name="submit" value="<?php echo __('Save Changes');?>">
    <input type="reset"  class="btn btn-primary" name="reset"  value="<?php echo __('Reset Changes');?>">
    <input type="button" class="btn btn-primary" name="cancel" value="<?php echo __('Cancel Changes');?>" onclick='window.location.href="index.php"'>
</p>
</form>
